
Instalacja SimpleScore (AnarchiaFFA):

1. Wejdź do folderu "plugins/SimpleScore" na swoim serwerze.
2. Usuń istniejące pliki "config.yml" i "scoreboards.yml".
3. Wgraj nowe pliki "config.yml" oraz "scoreboards.yml" z tej paczki.
4. Zrestartuj serwer lub użyj komendy: /simplescore reload.
5. Sprawdź, czy scoreboard "AnarchiaFFA" działa poprawnie na serwerze.

Jeśli potrzebujesz pomocy przy konfiguracji lub modyfikacjach, skontaktuj się ze mną!
